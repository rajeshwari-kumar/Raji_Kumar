	describe('Main Controller', function() {
		beforeEach(module('portfolio'));
		var ctrl;
		var wndw;

		beforeEach(inject(function(_$controller_,_$window_) {
			ctrl = _$controller_;
			wndw = _$window_;
		}));

		describe('Pop Questions Functions', function() {
			it('calling pop question function or not', function() {
				var resource ={
				"profiles": {
					"id": "",
					"portfolio_id": "",
					"last_saved": "",
					"created": "",
					"sections": [{
						"section_id": "ABOUT_ME",
						"chicklets": [{
							"_id": "580845926aee060d2b140782",
							"chickletid": "PROFILE_DATA",
							"chicklet_data": {
								"name": {
									"value": "hf",
									"displayName": "I am "
								},
								"heading": {
									"displayName": "Personal Info"
								},
								"image": {
									"displayName": "Profile Pic"
								},
								"designation": {
									"value": "rtgergy",
									"displayName": "working as "
								},
								"organization": {
									"value": "ergterhy",
									"displayName": "in "
								},
								"current_location": {
									"value": "oct 6",
									"displayName": "at "
								},
								"age": {
									"value": "21",
									"displayName": "I'm "
								},
								"date_of_birth": {
									"value": "2015-10-24T18:30:00.000Z",
									"displayName": "and I was born on "
								}
							},
							"chicklet-directive-name": "personal-info",
							"placeholderId": "profile-a",
							"order-in-placeholder": "1",
							"chicklet-name": "profile"
						}, {
							"_id": "580845926aee060d2b140783",
							"chickletid": "CONTACT_INFORMATION",
							"chicklet_data": {
								"email": {
									"value": "def@def",
									"displayName": "My e-mail address"
								},
								"heading": {
									"displayName": "contact Info"
								},
								"phones": {
									"value": "qdfhda",
									"displayName": "Call me at "
								},
								"address": {
									"value": "q",
									"displayName": "My hometown is "
								},
								"linkedin": {
									"value": "q",
									"displayName": "My Linkedin account "
								},
								"facebook": {
									"value": "q",
									"displayName": "My Facebook account "
								},
								"github": {
									"value": "sdf",
									"displayName": "My GitHub account "
								}
							},
							"chicklet-directive-name": "contact-info",
							"placeholderId": "contact-c",
							"order-in-placeholder": "3",
							"chicklet-name": "contact"
						}],
						"section_directive_name": "about-me",
						"order": "1",
						"heading": {
							"displayName": "\"About Me\""
						},
						"placeholders": [{
							"placeholderId": "profile-a",
							"width": 100,
							"chickletRowSize": 1,
							"chickletCount": 1,
							"chickletWidth": 100,
							"height": 100
						}, {
							"placeholderId": "contact-c",
							"width": 100,
							"chickletRowSize": 2.86,
							"chickletCount": 1,
							"chickletWidth": 100,
							"height": 50
						}, {
							"placeholderId": "other-b",
							"width": 100,
							"chickletRowSize": 1,
							"chickletCount": 1,
							"chickletWidth": 100,
							"height": 50
						}, {
							"placeholderId": "summary-d",
							"width": 50,
							"chickletRowSize": 1.5,
							"chickletCount": 1,
							"chickletWidth": 50,
							"height": 50
						}],
						"showSection": true,
						"section_directive_name_dnd": "about-me-dnd",
						"section_name": "About Me(Template two)"
					}, {
						"section_id": "PROFESSIONAL_EXPERIENCE",
						"section_directive_name": "professional-exp",
						"order": "2",
						"heading": {
							"displayName": "\"Professional Experience\""
						},
						"placeholders": [{
							"placeholderId": "placeholder-s",
							"width": 50,
							"chickletRowSize": 0.46,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-r",
							"width": 50,
							"chickletRowSize": 0.85,
							"chickletCount": 1,
							"chickletWidth": 100
						}],
						"chicklets": []
					}, {
						"section_id": "ENDORSEMENTS",
						"section_directive_name": "endorsements-section",
						"order": "2",
						"heading": {
							"displayName": "Endorsements"
						},
						"placeholders": [{
							"placeholderId": "placeholder-f",
							"width": 100,
							"chickletRowSize": 2,
							"chickletCount": 1,
							"chickletWidth": 100
						}],
						"chicklets": []
					}, {
						"section_id": "ACCOMPLISHMENTS_AND_INTERESTS",
						"section_directive_name": "interest-section",
						"order": "2",
						"heading": {
							"displayName": "\"Accomplishments & Interests\""
						},
						"placeholders": [{
							"placeholderId": "placeholder-a",
							"width": 100,
							"chickletRowSize": 1.5,
							"chickletCount": 2,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-b",
							"width": 100,
							"chickletRowSize": 2,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-c",
							"width": 50,
							"chickletRowSize": 1,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-d",
							"width": 50,
							"chickletRowSize": 1,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-e",
							"width": 50,
							"chickletRowSize": 0.5,
							"chickletCount": 1,
							"chickletWidth": 100
						}],
						"chicklets": []
					}, {
						"section_id": "PROJECTS",
						"section_directive_name": "project-section",
						"heading": {
							"displayName": "Projects"
						},
						"order": "1",
						"placeholders": [{
							"placeholderId": "project-a",
							"width": 100,
							"chickletRowSize": 4.5,
							"chickletCount": 2,
							"chickletWidth": 50
						}],
						"chicklets": []
					}, {
						"section_id": "EDUCATION",
						"section_directive_name": "education-section",
						"heading": {
							"displayName": "Education"
						},
						"order": "3",
						"placeholders": [{
							"placeholderId": "placeholder-p",
							"width": 100,
							"chickletRowSize": 1,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-q",
							"width": 100,
							"chickletRowSize": 0.9,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-r",
							"width": 100,
							"chickletRowSize": 0.85,
							"chickletCount": 1,
							"chickletWidth": 100
						}],
						"chicklets": []
					}, {
						"section_id": "LOCATION",
						"section_directive_name": "location-section",
						"heading": {
							"displayName": "Locations"
						},
						"order": "4",
						"placeholders": [{
							"placeholderId": "placeholder-h",
							"width": 100,
							"chickletRowSize": 0.9,
							"chickletCount": 1,
							"chickletWidth": 100
						}, {
							"placeholderId": "placeholder-i",
							"width": 100,
							"chickletRowSize": 0.9,
							"chickletCount": 1,
							"chickletWidth": 100
						}],
						"chicklets": []
					}, {
						"section_id": "NETWORK_OF_PEOPLE",
						"section_directive_name": "network",
						"heading": {
							"displayName": "\"My Network\""
						},
						"order": "1",
						"placeholders": [{
							"placeholderId": "placeholder-neta",
							"width": 100,
							"chickletRowSize": 1.8,
							"chickletCount": 4,
							"chickletWidth": 25
						}, {
							"placeholderId": "placeholder-netb",
							"width": 100,
							"chickletRowSize": 1.8,
							"chickletCount": 4,
							"chickletWidth": 25
						}],
						"chicklets": []
					}, {
						"section_id": "SKILLS",
						"section_directive_name": "skill-section",
						"heading": {
							"displayName": "Skills"
						},
						"order": "1",
						"placeholders": [{
							"placeholderId": "placeholder-skilla",
							"width": 100,
							"chickletRowSize": 1.8,
							"chickletCount": 2,
							"chickletWidth": 50
						}],
						"chicklets": []
					}],
					"_id": "57e8ca700ab9b49174edea08"
				}
			}
				var scp = {};
				var ctrl1 = ctrl('mainCtrl', { $scope : scp });
				scp.mongoId = {"userId" : "5808c28d5ca993132208312c",
	        "chickletId" : [
	                "5808c3255ca9931322083134",
	                "5808c3255ca9931322083136"
	        ]};
				scp.popupQuestion(resource);
			});
		});
	});
