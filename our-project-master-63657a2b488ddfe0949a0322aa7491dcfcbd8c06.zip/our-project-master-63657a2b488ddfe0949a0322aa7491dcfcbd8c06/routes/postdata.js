var express = require('express');
var router = express.Router();
var ObjectId = require('mongodb').ObjectID;
var formidable = require('formidable');
var path = require('path');
var fs = require('fs');
var _ = require('lodash');
router.patch("/postdata", function(req, res, next) {
var chicklet1 = {};
var db = require("../db/mongoUtil").getConnection();

var form = formidable.IncomingForm({
    uploadDir: path.join(__dirname,'../public/images'), // don't forget the __dirname here
    keepExtensions: true
});

form.parse(req, function(err, fields, files) {
    if (err)
        throw err;
    body = fields.resource;
    newchickletid = fields.newchickletid;
    body = JSON.parse(body);

    body.profiles.sections.forEach(function(section) {
        section.chicklets.forEach(function(chicklet) {
            if (files && files.file && section.section_id === "ABOUT_ME" && chicklet.chickletid === "PROFILE_DATA" && chicklet._id === newchickletid) {

                var fileName = path.basename(files.file.path, path.extname(files.file.path));
                fs.rename(files.file.path, path.dirname(files.file.path) + "/" + body._id + fileExt, function(err) {

                });
                chicklet.chicklet_data.image["value"] = ' /images/' + body._id + fileExt;
            }
          chicklet._id = ObjectId();
        });
    });

    var smartQuestion = {};
    smartQuestion.userId = body._id;
    smartQuestion.chickletId= [];
    var userProfile = (body.profiles);
    for (var section of userProfile.sections){
      if(section.section_id==="SKILLS" || section.section_id==="PROJECTS"){
     for(var chicklet of section.chicklets){
      for(var key in chicklet.chicklet_data){
            if((chicklet.chicklet_data[key].value === '' || chicklet.chicklet_data[key].value === undefined) && key !== 'heading' && key !== 'project_specs' )
                {
                  res.status(200);
                var chickletId=chicklet._id.toString();
                smartQuestion.chickletId.push(chickletId);
                  break;
                }
                  }
                }
              }
            }

  userProfile.sections.forEach(function(section) {
      section.chicklets.forEach(function(chicklet) {
          for (key in chicklet.chicklet_data) {

              if (typeof chicklet.chicklet_data[key] === "object") {
                  delete chicklet.chicklet_data[key]["displayName"];
              }
          }
      });
  });

  db.collection('chickletIds').replaceOne(
      {"userId":body._id},
      smartQuestion,
      {upsert:true});

  db.collection('user_profile').update({
        "_id": ObjectId(body._id)
    }, {
        $set: {
            "profiles": userProfile
        }
    });

    res.status(200).json(body);
    var termExtraction = require("../routes/termbackup").buildIndexes(body);

});
});
module.exports = router;
