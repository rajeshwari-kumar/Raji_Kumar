var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://10.219.85.96:27017/Portfolio-Management';

router.get('/chicklet',function(req,res,next)
{
  mongoClient.connect(url, function(err, db) {

      if (err) {
          console.log(err);
      } else {
          var cursor = db.collection('chicklet_definition');
          var sections = cursor.find().toArray(function(err, data) {
              var obj;
              var sections = "";
              if (err) throw err;
            
              res.json(data);
          });
      }
  });
});
module.exports = router;
