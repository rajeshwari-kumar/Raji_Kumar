var _ = require('lodash');
var ObjectId = require("mongodb").ObjectID;

module.exports = function(profile,portfolio,cb) {
  var mergedChicklets=[];
  var userProfile=[];
  var portfolioDefn=[];
  var mergedobj=[];
  var db = require("../db/mongoUtil").getConnection();
  db.collection('portfolio_cache').find({"userId":ObjectId(profile._id),"portfolioId": ObjectId(portfolio._id)}).toArray(function(err, object) {
    if(object.length > 0) {
      res.status(200).json(object);
    }
    else {
        userProfile = [profile];
          portfolioDefn = [portfolio];
          var userId = userProfile[0]._id;
          finalObj = {};
          _.merge(finalObj,userProfile[0],portfolioDefn[0]);
          finalObj.profiles.sections = _.map(userProfile[0].profiles.sections,function(section) {
            var portfolioDefnSection = _.find(portfolioDefn[0].profiles.sections,{section_id:section.section_id});
            var mergedSection = {};
            if(portfolioDefnSection !== undefined) {
            _.merge(mergedSection,section,portfolioDefnSection)
            mergedSection.chicklets = section.chicklets.map(function(chicklet) {
              var portfolioDefnChicklet = _.find(portfolioDefnSection.chicklets,{'chickletid':chicklet['chickletid']});
                if(portfolioDefnChicklet !== undefined) {
                  var mergedChicklet = {};
                  _.merge(mergedChicklet,chicklet,portfolioDefnChicklet);
                  return mergedChicklet;
                };
            });
            mergedSection.chicklets = mergedSection.chicklets.filter(function(chicklet) {
                if(chicklet !== undefined) {
                  return chicklet;
                }
            });
            return mergedSection;
          };
          });

          finalObj.profiles.sections = finalObj.profiles.sections.filter(function(section) {
            if(section !== undefined) {
              return true;
            }
          });

          Array.prototype.push.apply(finalObj.profiles.sections,portfolioDefn[0].profiles.sections.filter(function(portfolioDefnSection) {
            for(finalObjSections of finalObj.profiles.sections) {
              if(finalObjSections.section_id === portfolioDefnSection.section_id) {
                return false;
              }
            };
            return true;
          }));
          var tempObj = _.clone(finalObj);

          finalObj.profiles.sections.forEach(function(section,index) {
            section.chicklets = section.chicklets.filter(function(chicklet) {
              var toBeDeleted = true;
              for(property in chicklet.chicklet_data) {
                if(_.has(chicklet.chicklet_data,[property,"value"])) {
                  toBeDeleted = false;
                }
              };
              return !toBeDeleted;
            });
          });
          cb([finalObj]);
          finalObj=[];
    }
  });
};
