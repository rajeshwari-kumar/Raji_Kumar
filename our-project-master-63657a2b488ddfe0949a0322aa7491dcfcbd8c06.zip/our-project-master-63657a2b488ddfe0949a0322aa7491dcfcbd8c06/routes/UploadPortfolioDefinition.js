var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://10.219.85.96:27017/Portfolio-Management';

router.post('/UploadPortfolioDefinition',function(req,res,next)
{
var Obj={
    'userId':req.body['userId'],
    'global_chicklet_obj':req.body['global_chicklet_obj'],
    'html':req.body['portfolioHTML'],
    'rendererObject':req.body['rendererObject'],
    'currentSection':req.body['currentSection'],
    'PortfolioName':req.body['PortfolioName'],
    'portfolioDef':req.body['portfolioDef'],
    'portfolioMongoId':req.body['portfolioMongoId'],
    'portfolioId':req.body['portfolioId'],
    'themeId' : req.body['themeId']
    };


  if (Obj['portfolioMongoId']===undefined && Obj['portfolioId']===undefined) {
    mongoClient.connect(url, function(err, db) {
        if (err) {

        } else {
            var cursor = db.collection('projectDefinition');
            cursor.insert(req.body['portfolioDef'], function(err, response) {
              Obj['portfolioId']=response.insertedIds[0];
              mongoClient.connect(url, function(err, db) {
                    if (err) {

                    } else {
                        var cursor = db.collection('user_portfolio');
                        cursor.insert(Obj, function(err, response) {
                        res.send(response.insertedIds[0]);
                      });
                    }
                });
              });
        }
    });
}else{
  mongoClient.connect(url, function(err, db) {
        if (err) {
        } else {
            var cursor = db.collection('projectDefinition');
            var o_id = require('mongodb').ObjectID(Obj['portfolioId']);
            cursor.update({"_id":o_id},req.body['portfolioDef'], function(err, response) {
                mongoClient.connect(url, function(err, db) {
                    if (err) {
                      } else {
                        var cursor = db.collection('user_portfolio');
                        var o_id2 = require('mongodb').ObjectID(Obj['portfolioMongoId']);
                        cursor.update({"_id":o_id2},Obj, function(err, response) {
                        });
                    }
                });
              });
        }
    });
  }
});
module.exports = router;
