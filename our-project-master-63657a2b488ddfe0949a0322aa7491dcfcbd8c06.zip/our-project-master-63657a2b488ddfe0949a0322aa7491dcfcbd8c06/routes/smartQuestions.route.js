var express = require('express');
var router = express.Router();
var ObjectId = require('mongodb').ObjectID;

router.get('/:profileId', function(req, res) {
  var db = require("../db/mongoUtil").getConnection();
    var profileId = req.params.profileId;
    db.collection('chickletIds').find({userId:profileId}).toArray(function(err, chickletids) {
      if(err) throw err;
      res.json(chickletids);
    });
});

module.exports = router;
