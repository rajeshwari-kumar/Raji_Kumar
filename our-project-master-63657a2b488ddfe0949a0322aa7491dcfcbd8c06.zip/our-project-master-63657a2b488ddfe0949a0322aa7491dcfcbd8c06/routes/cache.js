var express = require("express");
var router = express.Router();
var _ = require('lodash');
var ObjectId = require("mongodb").ObjectID;
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.21",neo4j.auth.basic('neo4j','1234'));
var session = driver.session();
router.get('/:username/getdata', function(req,res,next) {
  var mergedChicklets=[];
  var userProfile=[];
  var portfolioDefn=[];
  var mergedSections=[];
  var mergedobj=[];
    var db = require("../db/mongoUtil").getConnection();
    db.collection('portfolio_cache').find({"userId":ObjectId(req.params.username)}).toArray(function(err, object) {
        if(object.length > 0) {
          res.status(200).json(object);
        }
        else {

          db.collection('user_profile').find({"_id":ObjectId(req.params.username)}).toArray(function(err, doc) {
            userProfile=doc;
          db.collection('portfolio_definition').find().toArray(function(err, pdoc) {

            portfolioDefn=pdoc;

            var userId = userProfile[0]._id;
            finalObj=_.merge(userProfile[0],portfolioDefn[0]);
            finalObj.userId = userId;
            finalObj = _.omit(finalObj,"_id");
            userProfile[0].profiles.sections.forEach(function(userProfilesection,index) {
             portfolioDefn[0].profiles.sections.forEach(function(portfolioDefnsection,index) {
               if(userProfilesection.section_id == portfolioDefnsection.section_id) {
                  mergedSections=_.merge(userProfilesection,portfolioDefnsection);

                  userProfilesection.chicklets.forEach(function(userProfilechicklet,index) {
                     portfolioDefnsection.chicklets.forEach(function(portfolioDefnchicklet,index) {
                       if(userProfilechicklet['chicklet-directive-name'] == portfolioDefnchicklet['chicklet-directive-name']) {
                          mergedChicklets=_.merge(userProfilechicklet,portfolioDefnchicklet);

                          mergedSections.chicklets.forEach(function(chicklet,mergedSectionsindex) {

                          if(chicklet['chicklet-directive-name'] == mergedChicklets['chicklet-directive-name']) {

                            mergedChicklets._id=ObjectId();

                          mergedSections.chicklets[mergedSectionsindex] = mergedChicklets;

                        }
                      });
                       }
                   });
                 });

                mergedobj.push(mergedSections);
                }
             });
           });
            finalObj.profiles.sections=mergedobj;

            var tempObj = _.clone(finalObj);
            finalObj.profiles.sections.forEach(function(section,index) {
              section.chicklets = section.chicklets.filter(function(chicklet) {
                var toBeDeleted = true;
                for(property in chicklet.chicklet_data) {

                  if(_.has(chicklet.chicklet_data,[property,"value"])) {

                    toBeDeleted = false;
                  }
                };

                return !toBeDeleted;
              });

            });


            db.collection('portfolio_cache').insert(finalObj, function(err,cachedPortfolio) {

              res.json(cachedPortfolio);
            });
            finalObj=[];
        });
      });
      }
   });
});

//api for contact chips
router.get('/skills/:str?', function(req,res,next) {

    var db = require("../db/mongoUtil").getConnection();

    var queryString = 'MATCH (z:skills) where z.name starts with "'+ req.params.str + '" return z';
    session.run(queryString).then(function(skills) {
      var terms = [];
      skills.records.forEach(function(record) {
        var term = {};
        term[record._fields[0].properties.name] = "skills";
        term["skills"] = record._fields[0].properties.name;
        terms.push(term);
      });
      res.status(200).json(terms);
    }).catch(function(err) {

      res.status(500);
    });

  });

module.exports = router;
