var express=require('express');
var router=express.Router();
var ObjectId=require('mongodb').ObjectID;
var path=require('path');
var fs=require('fs');
router.get('/:userid'),function(req,res){
  var db=mongoUtil.getConnection();
  db.collection('smart_questions').find({'userid':ObjectId(body.userId)}).toArray(function(doc){
    res.send(doc);
    console.log('chkquesns');
  })
};
module.exports=router;
