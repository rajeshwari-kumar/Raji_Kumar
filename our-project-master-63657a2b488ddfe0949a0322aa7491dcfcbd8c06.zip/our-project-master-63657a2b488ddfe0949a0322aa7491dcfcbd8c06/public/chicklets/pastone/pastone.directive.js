angular.module('portfolio')
 .directive('pastoneCard',function() {
 return {
     templateUrl: '../js/directives/locationone/past/pastone.tmpl.html',
     scope: {
         sectionName:'@',
         chickletPath: '=chickletPath',
         theming : '='
     },
     controller: function($scope) {
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];

     }
 }
});
