angular.module('portfolio')
 .directive('endorsementoneChicklet',function() {
 return {
     templateUrl: '../js/directives/endrosementone/endorsementoneChicklet/endorseone.tmpl.html',
     scope: {
         sectionName:'@',
         chickletPath: '=chickletPath',
         theming : '='
     },
     controller: function($scope) {
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];

     }
 }
});
