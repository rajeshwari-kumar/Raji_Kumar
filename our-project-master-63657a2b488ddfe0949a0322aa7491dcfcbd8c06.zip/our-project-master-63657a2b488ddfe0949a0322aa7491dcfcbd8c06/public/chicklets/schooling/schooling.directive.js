angular.module('portfolio')
 .directive('dCard',function() {
 return {
     templateUrl: '../js/directives/educationSectionOne/schooling/schooling.tmpl.html',
     scope: {
         sectionName:'@',
         chickletPath: '=chickletPath',
         theming : '='
     },
     controller: function($scope) {
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];

     }
 }
});
