angular.module('portfolio')
.directive('certifiedChicklet',function(){
  return{
    templateUrl:'../js/directives/professional/certifiedChicklet/certifiedChicklet.temp.html',
    scope:{
      sectionName:'@',
      chickletPath: '=chickletPath',
      theming : '='
    },
    controller:function($scope){
      $scope.chickletData = $scope.chickletPath['chicklet_data'];
      $scope.chickletName = $scope.chickletPath['chickletid'];
  }
}
});
