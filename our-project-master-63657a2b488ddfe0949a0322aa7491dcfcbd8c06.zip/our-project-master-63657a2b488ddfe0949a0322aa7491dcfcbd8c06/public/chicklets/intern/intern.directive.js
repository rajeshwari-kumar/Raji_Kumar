angular.module('portfolio')
 .directive('cCard',function() {
 return {
     templateUrl: '../js/directives/educationSectionOne/intern/intern.tmpl.html',
     scope: {
         sectionName:'@',
       chickletPath: '=chickletPath',
          theming : '='
     },
     controller: function($scope) {
       $scope.chickletData = $scope.chickletPath['chicklet_data'];
       $scope.chickletName = $scope.chickletPath['chickletid'];
     }
 }
});
