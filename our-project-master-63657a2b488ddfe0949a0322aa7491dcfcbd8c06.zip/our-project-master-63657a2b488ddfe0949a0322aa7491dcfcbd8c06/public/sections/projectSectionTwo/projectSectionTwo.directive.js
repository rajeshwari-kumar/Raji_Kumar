angular.module('portfolio')
.directive('projectLightSection', function() {
  return {
      templateUrl: 'sections/projectSectionTwo/projectSectionTwo.templ.html',
      scope: {
        sectionName: '@',
        displayName:'@'
      },
      transclude: {
        'project-b': '?projectB',
        'project-c': '?projectC'
      }
  }
});
