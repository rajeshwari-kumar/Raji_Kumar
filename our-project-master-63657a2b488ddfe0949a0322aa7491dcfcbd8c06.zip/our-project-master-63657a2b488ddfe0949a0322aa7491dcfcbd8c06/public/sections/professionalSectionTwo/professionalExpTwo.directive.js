angular.module('portfolio')
.directive('professionalExpTwo',function(){
  return{
    templateUrl:"sections/professionalSectionTwo/professionalExpTwo.tmpl.html",
    scope:{
      sectionName: '@',
      displayName:'@'
    },
    transclude:{
      'placeholdertwo-s': '?placeholdertwoS',
      'placeholdertwo-r': '?placeholdertwoR',
      'placeholdertwo-p': '?placeholdertwoP'
    },
    controller:function($rootScope,$scope){
    
    }
  }
});
