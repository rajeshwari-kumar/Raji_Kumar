angular.module('portfolio')
  .directive('aboutMeOne', function() {
    return {
      templateUrl: 'sections/aboutSectionTwo/aboutMeOne.tmpl.html',
      scope: {
        sectionName: '@',
        displayName:'@'
      },
      transclude: {
        'profile': '?profile',
        'keyskills': '?keyskills',
        'other': '?other',
        'summary': '?summary'
      },
      controller: function($rootScope,$scope) {
      }
    }
  });
