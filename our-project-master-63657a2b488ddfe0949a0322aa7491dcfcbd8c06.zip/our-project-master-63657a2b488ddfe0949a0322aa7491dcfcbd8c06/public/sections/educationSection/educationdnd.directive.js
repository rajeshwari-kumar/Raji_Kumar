  angular.module('app')
  .directive('educationSectionDnd',function($compile){
      return {
        restrict:'CEA',
        templateUrl:function(elem,attr){
          if(attr.edit=="false"){
            return 'sections/educationSection/educationdnd.tmpl.html';
          }else if (attr.edit=="true") {

                      return '';
          }
        },
        link:function($scope,elem,attr){
          if(attr.edit=="true"){
            elem.html('');
            var html=$compile(attr.template)($scope);
            elem.append(html);
          }
        }
        ,
        scope: {
          template:'@',
          edit:'=edit',
          sectionName: '@',
          displayName:'@',
          removeButton:'&',
          dropChicklet:'&',
          removeSection:'&',
          removeChicklet:'&',
          showAdvanced:'&',
          sectionDndName:'@'
        },
        transclude: {
          'placeholder-p': '?placeholderP',
           'placeholder-q': '?placeholderQ',
           'placeholder-r': '?placeholderR'
        },
      }
    });
